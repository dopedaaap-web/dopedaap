"use client";

import React, { useEffect, useMemo, useState } from "react";

type Mode = "syn" | "related" | "rhyme" | "sound";
type SectionType =
  | "intro"
  | "verse"
  | "prechorus"
  | "chorus"
  | "bridge"
  | "outro"
  | "hook"
  | "interlude"
  | "instrumental"
  | "unknown";

type Result = { word: string; score: number | null; tags: string[] };

type HookCtx = {
  anchorWords: string[];
  rhymeKeys: string[];
  alliterationStarts: string[];
} | null;

async function fetchSuggestions(word: string, mode: Mode) {
  const r = await fetch(`/api/words?word=${encodeURIComponent(word)}&mode=${mode}`);
  return (await r.json()) as { results: Result[] };
}

function estimateSyllables(word: string): number {
  const w = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!w) return 0;
  if (w.length <= 3) return 1;
  const w2 = w.replace(/e$/,"");
  const groups = (w2.match(/[aeiouy]+/g) ?? []).length;
  return Math.max(1, groups);
}

function freqFromTags(tags: string[]): number {
  const t = tags.find(x => x.startsWith("f:"));
  if (!t) return 0;
  const n = Number(t.slice(2));
  return Number.isFinite(n) ? n : 0;
}

function rhymeKeyFromWord(word: string): string {
  let w = word.toLowerCase().replace(/[^a-z']/g, "");
  w = w.replace(/'s$/,"").replace(/(ing|ed)$/,"").replace(/e$/,"");
  const m = w.match(/([aeiouy]+[^aeiouy]*)$/);
  return (m ? m[1] : w.slice(-3))
    .replace(/ph/g,"f").replace(/ght/g,"t").replace(/ck/g,"k").replace(/tion/g,"shun");
}

function startKey(word: string): string {
  const w = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!w) return "";
  if (w.startsWith("sh")) return "sh";
  if (w.startsWith("ch")) return "ch";
  if (w.startsWith("th")) return "th";
  if (w.startsWith("ph")) return "f";
  return w[0];
}

function sectionBias(section: SectionType, r: Result): number {
  const w = r.word;
  const len = w.length;
  const syl = estimateSyllables(w);
  const freq = freqFromTags(r.tags);
  const base = (r.score ?? 0) / 100000;

  if (section === "chorus" || section === "hook") {
    const shortBonus = len <= 6 ? 0.35 : 0;
    const sylBonus = syl <= 2 ? 0.35 : 0;
    const freqBonus = Math.min(0.4, freq / 6);
    const penalty = len >= 10 || syl >= 4 ? 0.25 : 0;
    return base + shortBonus + sylBonus + freqBonus - penalty;
  }
  if (section === "prechorus") {
    const sylBonus = syl <= 3 ? 0.25 : 0;
    const freqBonus = Math.min(0.25, freq / 8);
    const penalty = syl >= 5 ? 0.2 : 0;
    return base + sylBonus + freqBonus - penalty;
  }
  if (section === "verse") {
    const specificityBonus = len >= 7 ? 0.2 : 0;
    const freqBonus = Math.min(0.15, freq / 12);
    return base + specificityBonus + freqBonus;
  }
  if (section === "bridge") {
    const noveltyBonus = freq < 2 ? 0.35 : 0;
    const lengthOk = len <= 12 ? 0.1 : 0;
    return base + noveltyBonus + lengthOk;
  }
  return base;
}

function hookBoost(word: string, hook: HookCtx, sectionType: SectionType): number {
  if (!hook) return 0;

  const hookMode =
    sectionType === "chorus" || sectionType === "hook" ? 1 :
    sectionType === "prechorus" ? 0.4 :
    0;

  if (hookMode === 0) return 0;

  const w = word.toLowerCase();
  const wRhy = rhymeKeyFromWord(w);
  const wStart = startKey(w);
  const syl = estimateSyllables(w);

  let score = 0;
  if (hook.anchorWords.includes(w)) score += 0.55;
  if (hook.alliterationStarts.includes(wStart)) score += 0.35;
  if (hook.rhymeKeys.includes(wRhy)) score += 0.45;
  if (syl <= 2) score += 0.20;
  if (syl >= 4) score -= 0.15;

  return score * hookMode;
}

export function SuggestionDrawer({
  trigger,
  section,
  hookContext,
  onSelect,
  onClose,
}: {
  trigger: { word: string; mode: "syn" | "rhyme" } | null;
  section: { type: SectionType; label: string } | null;
  hookContext: HookCtx;
  onSelect: (word: string) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<Mode>("syn");
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(0);

  const tabs: Mode[] = useMemo(() => {
    if (!trigger) return [];
    return trigger.mode === "syn" ? (["syn", "related"] as Mode[]) : (["rhyme", "sound"] as Mode[]);
  }, [trigger]);

  useEffect(() => {
    if (!trigger) return;
    setTab(trigger.mode === "syn" ? "syn" : "rhyme");
  }, [trigger]);

  useEffect(() => {
    if (!trigger) return;
    setLoading(true);
    fetchSuggestions(trigger.word, tab)
      .then((r) => setResults(r.results))
      .finally(() => setLoading(false));
  }, [trigger, tab]);

  const ranked = useMemo(() => {
    const secType = (section?.type ?? "unknown") as SectionType;
    return [...results].sort((a, b) => {
      const sb = sectionBias(secType, b) + hookBoost(b.word, hookContext, secType);
      const sa = sectionBias(secType, a) + hookBoost(a.word, hookContext, secType);
      return sb - sa;
    });
  }, [results, section, hookContext]);

  useEffect(() => {
    setActive(0);
  }, [trigger, tab, results.length, section?.type]);

  useEffect(() => {
    if (!trigger) return;

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (!ranked.length) return;

      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive((i) => Math.min(ranked.length - 1, i + 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive((i) => Math.max(0, i - 1));
      } else if (e.key === "Enter") {
        e.preventDefault();
        const w = ranked[active]?.word;
        if (w) onSelect(w);
      }
    }

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [trigger, ranked, active, onClose, onSelect]);

  if (!trigger) return null;

  return (
    <div
      style={{
        position: "fixed",
        right: 16,
        bottom: 16,
        width: 380,
        maxHeight: 360,
        background: "#fff",
        border: "1px solid #ddd",
        borderRadius: 12,
        padding: 12,
        boxShadow: "0 12px 30px rgba(0,0,0,0.15)",
        zIndex: 1000,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <div>
          <strong>Word Options</strong>
          <div style={{ fontSize: 11, opacity: 0.65, marginTop: 2 }}>
            {section ? `${section.label} bias` : "No section bias"} · {hookContext ? "hook-aware" : "hook: off"} · “{trigger.word}{trigger.mode === "syn" ? "?" : "~"}”
          </div>
        </div>
        <button onClick={onClose} style={{ border: "none", background: "transparent", cursor: "pointer" }}>
          ✕
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              padding: "6px 10px",
              borderRadius: 999,
              border: "1px solid #ddd",
              background: t === tab ? "#111" : "#f7f7f7",
              color: t === tab ? "#fff" : "#111",
              cursor: "pointer",
              fontSize: 12,
            }}
          >
            {t === "syn" && "Synonyms"}
            {t === "related" && "Related"}
            {t === "rhyme" && "Rhymes"}
            {t === "sound" && "Sounds-like"}
          </button>
        ))}
      </div>

      <div style={{ marginTop: 10 }}>
        {loading ? (
          <div style={{ opacity: 0.6 }}>Searching…</div>
        ) : ranked.length ? (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {ranked.slice(0, 20).map((r, idx) => {
              const isActive = idx === active;
              return (
                <button
                  key={r.word}
                  onClick={() => onSelect(r.word)}
                  onMouseEnter={() => setActive(idx)}
                  style={{
                    padding: "6px 10px",
                    borderRadius: 999,
                    border: "1px solid #ddd",
                    background: isActive ? "#111" : "#f8f8f8",
                    color: isActive ? "#fff" : "#111",
                    cursor: "pointer",
                    fontSize: 13,
                  }}
                >
                  {r.word}
                </button>
              );
            })}
          </div>
        ) : (
          <div style={{ opacity: 0.6 }}>No matches.</div>
        )}
      </div>

      <div style={{ marginTop: 10, fontSize: 11, opacity: 0.6 }}>
        Keys: ↑/↓ select · Enter insert · Esc close
      </div>
    </div>
  );
}
