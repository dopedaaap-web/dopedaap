export function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 14 }}>
      <strong>{title}</strong>
      <div style={{ marginTop: 10 }}>{children}</div>
    </div>
  );
}
