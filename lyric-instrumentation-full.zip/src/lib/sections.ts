export type SectionType =
  | "intro"
  | "verse"
  | "prechorus"
  | "chorus"
  | "bridge"
  | "outro"
  | "hook"
  | "interlude"
  | "instrumental"
  | "unknown";

export type InstrumentalRole =
  | "intro_space"
  | "outro_space"
  | "reset"
  | "buildup"
  | "extension"
  | "transition";

export type ParsedLine = { globalLine: number; text: string };

export type Section = {
  index: number;
  label: string;
  type: SectionType;
  startLine: number;
  endLine: number;
  lines: ParsedLine[];
};

function normalizeLabel(raw: string): { type: SectionType; label: string } {
  const s = raw.trim().toLowerCase();
  const pick = (type: SectionType, label: string) => ({ type, label });

  if (/(pre[\s-]?chorus|prechorus)/.test(s)) return pick("prechorus", "Pre-Chorus");
  if (/chorus|refrain/.test(s)) return pick("chorus", "Chorus");
  if (/verse/.test(s)) return pick("verse", "Verse");
  if (/bridge|middle\s*8/.test(s)) return pick("bridge", "Bridge");
  if (/intro/.test(s)) return pick("intro", "Intro");
  if (/outro|ending/.test(s)) return pick("outro", "Outro");
  if (/(instrumental|inst\.?|drop|beat\s*drop|solo|guitar\s*solo|piano\s*solo|no\s*vocals)/.test(s))
    return pick("instrumental", "Instrumental");
  if (/interlude|breakdown|break/.test(s)) return pick("interlude", "Interlude");
  if (/hook/.test(s)) return pick("hook", "Hook");

  return pick("unknown", raw.trim() || "Section");
}

function isSectionHeading(line: string): boolean {
  const t = line.trim();
  if (!t) return false;
  if (/^[\[\(\{].+[\]\)\}]$/.test(t)) return true;
  return /^(intro|verse|pre[-\s]?chorus|chorus|bridge|outro|hook|interlude|instrumental|inst\.?|breakdown|break|drop|solo)\b[\s0-9a-z-]*[:\-–—]?\s*$/i.test(t);
}

function extractHeadingText(line: string): string {
  const t = line.trim();
  if (/^[\[\(\{].+[\]\)\}]$/.test(t)) return t.slice(1, -1).trim();
  return t.replace(/[:\-–—]\s*$/g, "").trim();
}

export function parseSections(rawLyrics: string): Section[] {
  const raw = rawLyrics.split(/\r?\n/);
  const hasHeadings = raw.some((l) => isSectionHeading(l));

  const sections: Section[] = [];
  let current: Section | null = null;
  let globalLine = 0;

  const pushCurrent = () => {
    if (!current) return;
    if (current.lines.length === 0) return;
    current.startLine = current.lines[0].globalLine;
    current.endLine = current.lines[current.lines.length - 1].globalLine;
    sections.push(current);
  };

  if (hasHeadings) {
    for (const line of raw) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      if (isSectionHeading(trimmed)) {
        pushCurrent();
        const heading = extractHeadingText(trimmed);
        const norm = normalizeLabel(heading);
        current = {
          index: sections.length + 1,
          label: norm.label,
          type: norm.type,
          startLine: 0,
          endLine: 0,
          lines: [],
        };
        continue;
      }

      globalLine += 1;
      if (!current) {
        current = { index: 1, label: "Section 1", type: "unknown", startLine: 0, endLine: 0, lines: [] };
      }
      current.lines.push({ globalLine, text: trimmed });
    }
    pushCurrent();
    sections.forEach((s, i) => (s.index = i + 1));
    return sections;
  }

  // stanza fallback
  let stanzaLines: ParsedLine[] = [];
  let stanzaIndex = 0;

  const flushStanza = () => {
    if (!stanzaLines.length) return;
    stanzaIndex += 1;
    sections.push({
      index: stanzaIndex,
      label: `Stanza ${stanzaIndex}`,
      type: "unknown",
      startLine: stanzaLines[0].globalLine,
      endLine: stanzaLines[stanzaLines.length - 1].globalLine,
      lines: stanzaLines,
    });
    stanzaLines = [];
  };

  for (const line of raw) {
    const trimmed = line.trim();
    if (!trimmed) {
      flushStanza();
      continue;
    }
    globalLine += 1;
    stanzaLines.push({ globalLine, text: trimmed });
  }
  flushStanza();
  return sections;
}
