import type { LyricFingerprint } from "./lyricFingerprint";
import type { InstrumentalRole } from "./sections";

export type InstrumentalRoleMetrics = {
  sectionIndex: number;
  role: InstrumentalRole;
  positionPercent: number;
  emotionalBefore: number | null;
  emotionalAfter: number | null;
  deltaAcross: number | null;
  distanceToNearestHook: number | null;
};

function mean(xs: number[]): number { return xs.length ? xs.reduce((a,b)=>a+b,0)/xs.length : 0; }

function sectionAvgSentiment(fp: LyricFingerprint, start: number, end: number): number {
  const vals = fp.lines.filter(l => l.index >= start && l.index <= end).map(l => l.sentiment);
  return mean(vals);
}

function nearestHookDistance(hooks: number[], start: number, end: number): number | null {
  if (!hooks.length) return null;
  const center = Math.round((start + end) / 2);
  return Math.min(...hooks.map(h => Math.abs(h - center)));
}

export function computeInstrumentalRoles(fp: LyricFingerprint): InstrumentalRoleMetrics[] {
  const sections = fp.sections.metrics;
  const total = sections.length;
  const hooks = fp.patterns.hookZones;

  const out: InstrumentalRoleMetrics[] = [];

  for (let i = 0; i < sections.length; i++) {
    const s = sections[i];
    if (s.type !== "instrumental") continue;

    const prev = sections[i-1] ?? null;
    const next = sections[i+1] ?? null;

    const prevSent = prev ? sectionAvgSentiment(fp, prev.startLine, prev.endLine) : null;
    const nextSent = next ? sectionAvgSentiment(fp, next.startLine, next.endLine) : null;
    const delta = (prevSent !== null && nextSent !== null) ? (nextSent - prevSent) : null;
    const posPct = total > 1 ? (i / (total - 1)) * 100 : 0;

    let role: InstrumentalRole = "transition";
    if (i === 0) role = "intro_space";
    else if (i === total - 1) role = "outro_space";
    else if (prevSent !== null && nextSent !== null) {
      if (prevSent - nextSent >= 0.25) role = "reset";
      else if (nextSent - prevSent >= 0.25 && (next?.hookZones?.length ?? 0) > 0) role = "buildup";
      else if (Math.abs(nextSent - prevSent) < 0.1 && (prev?.hookZones?.length ?? 0) > 0) role = "extension";
    }

    out.push({
      sectionIndex: s.index,
      role,
      positionPercent: Math.round(posPct),
      emotionalBefore: prevSent,
      emotionalAfter: nextSent,
      deltaAcross: delta,
      distanceToNearestHook: nearestHookDistance(hooks, s.startLine, s.endLine),
    });
  }

  return out;
}
