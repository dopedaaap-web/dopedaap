import { parseSections } from "./sections";
import type { Section } from "./sections";
import { buildProsody } from "./prosody";
import { buildRhyme } from "./rhyme";
import { computeInstrumentalRoles, type InstrumentalRoleMetrics } from "./instrumentalRoles";

export type LineFingerprint = {
  index: number;
  text: string;
  sentiment: number; // -1..1
  imageryScore: number; // 0..1
};

export type RepetitionCluster = {
  phrase: string;
  lines: number[];
  strength: number;
};

export type SectionMetrics = {
  index: number;
  label: string;
  type: string;
  startLine: number;
  endLine: number;
  lineCount: number;
  wordCount: number;
  avgSentiment: number;
  avgImagery: number;
  hookZones: number[];
};

export type LyricFingerprint = {
  meta: { lineCount: number; wordCount: number };
  lines: LineFingerprint[];
  curves: { emotionalTrajectory: number[]; imageryDensity: number[] };
  patterns: { repetitionClusters: RepetitionCluster[]; hookZones: number[] };
  signals: {
    povShifts: { line: number; from: string; to: string }[];
    tenseShifts: { line: number; from: string; to: string }[];
  };
  sections: {
    items: Section[];
    metrics: SectionMetrics[];
    instrumentalRoles: InstrumentalRoleMetrics[];
  };
  prosody: ReturnType<typeof buildProsody>;
  rhyme: ReturnType<typeof buildRhyme>;
};

const POS = new Set(["love","hold","alive","light","home","hope","warm","safe","together","stay","save"]);
const NEG = new Set(["grief","pain","hate","alone","lost","dark","thin","wrong","broke","cold","fear","death","cry"]);

const IMAGERY = new Set(["rain","dust","street","light","shadow","blood","snow","fire","smoke","room","air","moon","stone","glass","water"]);

function tokenizeWords(text: string): string[] {
  return (text.toLowerCase().match(/[a-z']+/g) ?? []);
}

function mean(xs: number[]): number {
  if (!xs.length) return 0;
  return xs.reduce((a,b)=>a+b,0)/xs.length;
}

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

function sentimentOf(text: string): number {
  const ws = tokenizeWords(text);
  if (!ws.length) return 0;
  let s = 0;
  for (const w of ws) {
    if (POS.has(w)) s += 1;
    if (NEG.has(w)) s -= 1;
  }
  return clamp(s / Math.max(3, ws.length/2), -1, 1);
}

function imageryOf(text: string): number {
  const ws = tokenizeWords(text);
  if (!ws.length) return 0;
  let hits = 0;
  for (const w of ws) if (IMAGERY.has(w)) hits++;
  return clamp(hits / Math.max(4, ws.length), 0, 1);
}

function ngramClusters(lines: string[], n = 2): RepetitionCluster[] {
  const map = new Map<string, number[]>();
  for (let i = 0; i < lines.length; i++) {
    const ws = tokenizeWords(lines[i]);
    for (let j = 0; j <= ws.length - n; j++) {
      const g = ws.slice(j, j+n).join(" ");
      if (g.length < 4) continue;
      const arr = map.get(g) ?? [];
      arr.push(i+1);
      map.set(g, arr);
    }
  }
  const clusters: RepetitionCluster[] = [];
  for (const [phrase, ls] of map.entries()) {
    const uniq = Array.from(new Set(ls));
    if (uniq.length >= 2) {
      clusters.push({ phrase, lines: uniq, strength: clamp(uniq.length / 6, 0, 1) });
    }
  }
  clusters.sort((a,b)=>b.strength-a.strength);
  return clusters;
}

function hookZonesFromClusters(clusters: RepetitionCluster[]): number[] {
  const lines = new Set<number>();
  for (const c of clusters.slice(0, 6)) for (const l of c.lines) lines.add(l);
  return Array.from(lines).sort((a,b)=>a-b);
}

function detectPOV(line: string): string {
  const ws = tokenizeWords(line);
  if (ws.some(w => ["i","me","my","mine"].includes(w))) return "1st";
  if (ws.some(w => ["you","your","yours"].includes(w))) return "2nd";
  if (ws.some(w => ["he","she","they","them","his","her","their"].includes(w))) return "3rd";
  return "none";
}

function detectTense(line: string): string {
  const s = line.toLowerCase();
  if (/\b(was|were|did|had|went|said|felt|held|walked|watched)\b/.test(s)) return "past";
  if (/\b(will|shall|gonna)\b/.test(s)) return "future";
  return "present";
}

export function buildLyricFingerprint(rawLyrics: string): LyricFingerprint {
  const rawLines = rawLyrics.split(/\r?\n/);

  // content lines only (skip headings/blanks)
  const content: string[] = [];
  for (const line of rawLines) {
    const t = line.trim();
    if (!t) continue;
    // skip headings
    if (/^[\[\(\{].+[\]\)\}]$/.test(t)) continue;
    if (/^(intro|verse|pre[-\s]?chorus|chorus|bridge|outro|hook|interlude|instrumental|inst\.?|breakdown|break|drop|solo)\b/i.test(t)) continue;
    content.push(t);
  }

  const lineFingerprints: LineFingerprint[] = content.map((t, i) => ({
    index: i+1,
    text: t,
    sentiment: sentimentOf(t),
    imageryScore: imageryOf(t),
  }));

  const emoCurve = lineFingerprints.map(l => (l.sentiment + 1)/2);
  const imgCurve = lineFingerprints.map(l => l.imageryScore);

  const clusters = ngramClusters(content, 2);
  const hookZones = hookZonesFromClusters(clusters);

  // POV/tense shifts
  const povShifts: { line: number; from: string; to: string }[] = [];
  const tenseShifts: { line: number; from: string; to: string }[] = [];
  let prevPOV = "none";
  let prevTense = "present";
  for (const l of lineFingerprints) {
    const pov = detectPOV(l.text);
    const ten = detectTense(l.text);
    if (pov !== prevPOV) povShifts.push({ line: l.index, from: prevPOV, to: pov });
    if (ten !== prevTense) tenseShifts.push({ line: l.index, from: prevTense, to: ten });
    prevPOV = pov;
    prevTense = ten;
  }

  const sections = parseSections(rawLyrics);

  const sectionMetrics: SectionMetrics[] = sections.map((sec) => {
    const lineIdxs = sec.lines.map((l) => l.globalLine);
    const fps = lineIdxs.map((n) => lineFingerprints[n-1]).filter(Boolean);
    const words = fps.reduce((sum, x) => sum + tokenizeWords(x.text).length, 0);
    const sent = fps.map(x => x.sentiment);
    const img = fps.map(x => x.imageryScore);
    const hook = hookZones.filter(hz => hz >= sec.startLine && hz <= sec.endLine);

    return {
      index: sec.index,
      label: sec.label,
      type: sec.type,
      startLine: sec.startLine,
      endLine: sec.endLine,
      lineCount: sec.lines.length,
      wordCount: words,
      avgSentiment: mean(sent),
      avgImagery: mean(img),
      hookZones: hook,
    };
  });

  const simpleLines = lineFingerprints.map(l => ({ index: l.index, text: l.text }));
  const prosody = buildProsody(simpleLines);
  const rhyme = buildRhyme(simpleLines);

  const fp: LyricFingerprint = {
    meta: {
      lineCount: lineFingerprints.length,
      wordCount: lineFingerprints.reduce((s, l) => s + tokenizeWords(l.text).length, 0),
    },
    lines: lineFingerprints,
    curves: { emotionalTrajectory: emoCurve, imageryDensity: imgCurve },
    patterns: { repetitionClusters: clusters, hookZones },
    signals: { povShifts, tenseShifts },
    sections: { items: sections, metrics: sectionMetrics, instrumentalRoles: [] },
    prosody,
    rhyme,
  };

  fp.sections.instrumentalRoles = computeInstrumentalRoles(fp);

  return fp;
}
