export type TriggerMode = "syn" | "rhyme";

export function findTriggerAtCursor(text: string, cursor: number): { start: number; end: number; word: string; mode: TriggerMode } | null {
  const beforeRaw = text.slice(0, cursor);
  const before = beforeRaw.replace(/\s+$/,"");
  const end = before.length;

  const m = before.match(/([A-Za-z']+)([?~])$/);
  if (!m) return null;

  const word = m[1];
  const suffix = m[2];
  const mode: TriggerMode = suffix === "?" ? "syn" : "rhyme";
  const start = end - (word.length + 1);
  return { start, end, word, mode };
}

export function replaceRange(text: string, start: number, end: number, replacement: string) {
  return text.slice(0, start) + replacement + text.slice(end);
}
