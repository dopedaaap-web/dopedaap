export type RhymeLine = {
  line: number;
  endWord: string | null;
  rhymeKey: string | null;
  family: string | null;
};

export type RhymeFamily = {
  family: string;
  key: string;
  lines: number[];
  strength: number;
};

export type RhymeReport = {
  lines: RhymeLine[];
  families: RhymeFamily[];
  stability: number;
};

function lastWord(line: string): string | null {
  const m = line.toLowerCase().match(/([a-z']+)\W*$/);
  return m?.[1] ?? null;
}

function rhymeKeyFromWord(word: string): string {
  let w = word.toLowerCase().replace(/[^a-z']/g, "");
  w = w.replace(/'s$/,"");
  w = w.replace(/(ing|ed)$/,"");
  w = w.replace(/e$/,"");
  const m = w.match(/([aeiouy]+[^aeiouy]*)$/);
  if (!m) return w.slice(-3);
  return m[1].replace(/ph/g,"f").replace(/ght/g,"t").replace(/ck/g,"k").replace(/tion/g,"shun");
}

function mean(xs: number[]): number {
  if (!xs.length) return 0;
  return xs.reduce((a,b)=>a+b,0)/xs.length;
}

export function buildRhyme(lines: { index: number; text: string }[]): RhymeReport {
  const rhymeLines: RhymeLine[] = [];
  const keyToLines = new Map<string, number[]>();

  for (const l of lines) {
    const lw = lastWord(l.text);
    if (!lw) {
      rhymeLines.push({ line: l.index, endWord: null, rhymeKey: null, family: null });
      continue;
    }
    const key = rhymeKeyFromWord(lw);
    rhymeLines.push({ line: l.index, endWord: lw, rhymeKey: key, family: null });
    const arr = keyToLines.get(key) ?? [];
    arr.push(l.index);
    keyToLines.set(key, arr);
  }

  const entries = Array.from(keyToLines.entries())
    .map(([key, ls]) => ({ key, lines: ls }))
    .sort((a,b) => b.lines.length - a.lines.length);

  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const families: RhymeFamily[] = [];
  entries.slice(0, 26).forEach((e, i) => {
    const fam = alphabet[i] ?? `F${i+1}`;
    const strength = Math.max(0, Math.min(1, e.lines.length / 6));
    families.push({ family: fam, key: e.key, lines: e.lines, strength });
  });

  const keyToFamily = new Map(families.map(f => [f.key, f.family] as const));
  for (const rl of rhymeLines) {
    if (rl.rhymeKey && keyToFamily.has(rl.rhymeKey)) rl.family = keyToFamily.get(rl.rhymeKey)!;
  }

  const adj: number[] = [];
  for (let i = 1; i < rhymeLines.length; i++) {
    const a = rhymeLines[i-1].family;
    const b = rhymeLines[i].family;
    if (!a || !b) continue;
    adj.push(a === b ? 1 : 0);
  }

  return { lines: rhymeLines, families, stability: mean(adj) };
}
