export type ProsodyLineMetrics = {
  line: number;
  syllables: number;
  syllablesPerWord: number;
  density: number;
  plosiveCount: number;
  sibilantCount: number;
  vowelOpenness: number; // 0..1
  tripRisk: number; // 0..1
};

export type ProsodySummary = {
  avgSyllables: number;
  syllableStdDev: number;
  densityAvg: number;
  tripRiskAvg: number;
  mostDenseLine: number | null;
  mostDenseSyllables: number;
};

const PLOSIVES = new Set(["p","b","t","d","k","g"]);

function words(line: string): string[] {
  return (line.toLowerCase().match(/[a-z']+/g) ?? []);
}

function estimateSyllables(word: string): number {
  const w = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!w) return 0;
  if (w.length <= 3) return 1;
  const w2 = w.replace(/e$/,"");
  const groups = (w2.match(/[aeiouy]+/g) ?? []).length;
  return Math.max(1, groups);
}

function countPlosives(line: string): number {
  const s = line.toLowerCase();
  let count = 0;
  for (const ch of s) if (PLOSIVES.has(ch)) count++;
  return count;
}

function countSibilants(line: string): number {
  const s = line.toLowerCase();
  let count = 0;
  for (const ch of s) if (ch === "s" || ch === "z" || ch === "x") count++;
  const digraphs = (s.match(/sh|ch/g) ?? []).length;
  return count + digraphs;
}

function vowelOpenness(line: string): number {
  const s = line.toLowerCase();
  const vowels = (s.match(/[aeiouy]/g) ?? []).length;
  if (!vowels) return 0;
  const open = (s.match(/[ao]/g) ?? []).length;
  return Math.max(0, Math.min(1, open / vowels));
}

function consonantClusterScore(line: string): number {
  const s = line.toLowerCase().replace(/[^a-z]/g, " ");
  const clusters = (s.match(/\b[^aeiouy\s]{3,}\b/g) ?? []).length;
  return Math.min(1, clusters / 3);
}

function mean(xs: number[]): number {
  if (!xs.length) return 0;
  return xs.reduce((a,b)=>a+b,0)/xs.length;
}

function stddev(xs: number[]): number {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  const v = mean(xs.map(x => (x - m) ** 2));
  return Math.sqrt(v);
}

export function buildProsody(lines: { index: number; text: string }[]): { perLine: ProsodyLineMetrics[]; summary: ProsodySummary } {
  const perLine: ProsodyLineMetrics[] = [];

  for (const l of lines) {
    const ws = words(l.text);
    const syl = ws.reduce((sum, w) => sum + estimateSyllables(w), 0);
    const spw = ws.length ? syl / ws.length : 0;
    const plos = countPlosives(l.text);
    const sib = countSibilants(l.text);
    const open = vowelOpenness(l.text);
    const cluster = consonantClusterScore(l.text);
    const density = syl;

    const tripRiskRaw =
      (density / 18) * 0.55 +
      Math.min(1, plos / 20) * 0.25 +
      cluster * 0.20;

    perLine.push({
      line: l.index,
      syllables: syl,
      syllablesPerWord: spw,
      density,
      plosiveCount: plos,
      sibilantCount: sib,
      vowelOpenness: open,
      tripRisk: Math.max(0, Math.min(1, tripRiskRaw)),
    });
  }

  const syllablesArr = perLine.map(x => x.syllables);
  const densityArr = perLine.map(x => x.density);
  const riskArr = perLine.map(x => x.tripRisk);

  let mostDenseLine: number | null = null;
  let mostDenseSyllables = 0;
  for (const x of perLine) {
    if (x.syllables > mostDenseSyllables) {
      mostDenseSyllables = x.syllables;
      mostDenseLine = x.line;
    }
  }

  return {
    perLine,
    summary: {
      avgSyllables: mean(syllablesArr),
      syllableStdDev: stddev(syllablesArr),
      densityAvg: mean(densityArr),
      tripRiskAvg: mean(riskArr),
      mostDenseLine,
      mostDenseSyllables,
    },
  };
}
