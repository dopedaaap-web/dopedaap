import type { LyricFingerprint } from "./lyricFingerprint";

export type HookContext = {
  hookLines: number[];
  hookTexts: string[];
  anchorWords: string[];
  endWords: string[];
  rhymeKeys: string[];
  alliterationStarts: string[];
};

function words(s: string): string[] {
  return (s.toLowerCase().match(/[a-z']+/g) ?? []);
}

function lastWord(line: string): string | null {
  const m = line.toLowerCase().match(/([a-z']+)\W*$/);
  return m?.[1] ?? null;
}

function rhymeKeyFromWord(word: string): string {
  let w = word.toLowerCase().replace(/[^a-z']/g, "");
  w = w.replace(/'s$/,"").replace(/(ing|ed)$/,"").replace(/e$/,"");
  const m = w.match(/([aeiouy]+[^aeiouy]*)$/);
  if (!m) return w.slice(-3);
  return m[1].replace(/ph/g,"f").replace(/ght/g,"t").replace(/ck/g,"k").replace(/tion/g,"shun");
}

function startKey(word: string): string {
  const w = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!w) return "";
  if (w.startsWith("sh")) return "sh";
  if (w.startsWith("ch")) return "ch";
  if (w.startsWith("th")) return "th";
  if (w.startsWith("ph")) return "f";
  return w[0];
}

export function buildHookContext(fp: LyricFingerprint, cursorLine?: number, cursorSectionIndex?: number): HookContext | null {
  const hookLines = fp.patterns.hookZones ?? [];
  if (!hookLines.length) return null;

  let activeHookLines = hookLines;

  if (cursorSectionIndex) {
    const sec = fp.sections.metrics.find(s => s.index === cursorSectionIndex);
    if (sec) {
      const inSection = hookLines.filter(l => l >= sec.startLine && l <= sec.endLine);
      if (inSection.length) {
        activeHookLines = inSection;
      } else {
        const chorusLike = fp.sections.metrics.filter(s => s.type === "chorus" || s.type === "hook");
        if (chorusLike.length && cursorLine) {
          const nearest = chorusLike
            .map(s => ({ s, dist: Math.abs(((s.startLine + s.endLine)/2) - cursorLine) }))
            .sort((a,b)=>a.dist-b.dist)[0]?.s;
          if (nearest) {
            const chorusHooks = hookLines.filter(l => l >= nearest.startLine && l <= nearest.endLine);
            if (chorusHooks.length) activeHookLines = chorusHooks;
          }
        }
      }
    }
  } else if (cursorLine) {
    const window = { min: cursorLine - 6, max: cursorLine + 6 };
    const scoped = hookLines.filter(l => l >= window.min && l <= window.max);
    if (scoped.length) activeHookLines = scoped;
  }

  const hookTexts = activeHookLines.map(n => fp.lines[n-1]?.text).filter(Boolean) as string[];

  const stop = new Set(["the","a","an","and","or","but","to","of","in","on","for","with","my","your","you","i","me","we","us","is","are","was","were","be","been","it","that","this"]);
  const freq = new Map<string, number>();

  for (const t of hookTexts) {
    for (const w of words(t)) {
      if (w.length <= 2) continue;
      if (stop.has(w)) continue;
      freq.set(w, (freq.get(w) ?? 0) + 1);
    }
  }

  const anchorWords = Array.from(freq.entries()).sort((a,b)=>b[1]-a[1]).slice(0, 6).map(([w])=>w);
  const endWords = hookTexts.map(t => lastWord(t)).filter(Boolean) as string[];
  const rhymeKeys = Array.from(new Set(endWords.map(rhymeKeyFromWord))).slice(0, 6);
  const alliterationStarts = Array.from(new Set(anchorWords.map(startKey).filter(Boolean))).slice(0, 6);

  return { hookLines: activeHookLines, hookTexts, anchorWords, endWords, rhymeKeys, alliterationStarts };
}
