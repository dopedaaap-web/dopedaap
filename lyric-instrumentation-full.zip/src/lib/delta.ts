import type { LyricFingerprint, RepetitionCluster } from "./lyricFingerprint";

export type CurveDeltaPoint = { line: number; a: number; b: number; delta: number };

export type DeltaReport = {
  meta: { baselineLines: number; revisedLines: number };
  curves: {
    emotional: CurveDeltaPoint[];
    imagery: CurveDeltaPoint[];
    summary: {
      emotionalMeanDelta: number;
      emotionalAbsMeanDelta: number;
      imageryMeanDelta: number;
      imageryAbsMeanDelta: number;
    };
  };
  repetition: { added: RepetitionCluster[]; removed: RepetitionCluster[]; unchanged: RepetitionCluster[] };
  signals: {
    povAdded: { line: number; from: string; to: string }[];
    povRemoved: { line: number; from: string; to: string }[];
    tenseAdded: { line: number; from: string; to: string }[];
    tenseRemoved: { line: number; from: string; to: string }[];
  };
};

function mean(xs: number[]): number { return xs.length ? xs.reduce((a,b)=>a+b,0)/xs.length : 0; }
function absMean(xs: number[]): number { return xs.length ? xs.reduce((a,b)=>a+Math.abs(b),0)/xs.length : 0; }

function clusterKey(c: RepetitionCluster): string { return c.phrase; }

function diffClusters(a: RepetitionCluster[], b: RepetitionCluster[]) {
  const A = new Map(a.map(c => [clusterKey(c), c] as const));
  const B = new Map(b.map(c => [clusterKey(c), c] as const));
  const added: RepetitionCluster[] = [];
  const removed: RepetitionCluster[] = [];
  const unchanged: RepetitionCluster[] = [];
  for (const [k, bc] of B.entries()) (!A.has(k) ? added : unchanged).push(bc);
  for (const [k, ac] of A.entries()) if (!B.has(k)) removed.push(ac);
  added.sort((x,y)=>y.strength-x.strength);
  removed.sort((x,y)=>y.strength-x.strength);
  unchanged.sort((x,y)=>y.strength-x.strength);
  return { added, removed, unchanged };
}

function signalKey(s: { line: number; from: string; to: string }) { return `${s.line}:${s.from}->${s.to}`; }

function diffSignals(a: { line: number; from: string; to: string }[], b: { line: number; from: string; to: string }[]) {
  const A = new Set(a.map(signalKey));
  const B = new Set(b.map(signalKey));
  return {
    added: b.filter(s => !A.has(signalKey(s))),
    removed: a.filter(s => !B.has(signalKey(s))),
  };
}

export function buildDeltaReport(baseline: LyricFingerprint, revised: LyricFingerprint): DeltaReport {
  const maxLines = Math.max(baseline.curves.emotionalTrajectory.length, revised.curves.emotionalTrajectory.length);
  const emotional: CurveDeltaPoint[] = [];
  const imagery: CurveDeltaPoint[] = [];
  for (let i = 0; i < maxLines; i++) {
    const aE = baseline.curves.emotionalTrajectory[i] ?? 0;
    const bE = revised.curves.emotionalTrajectory[i] ?? 0;
    emotional.push({ line: i+1, a: aE, b: bE, delta: bE-aE });
    const aI = baseline.curves.imageryDensity[i] ?? 0;
    const bI = revised.curves.imageryDensity[i] ?? 0;
    imagery.push({ line: i+1, a: aI, b: bI, delta: bI-aI });
  }
  const emoD = emotional.map(p=>p.delta);
  const imgD = imagery.map(p=>p.delta);

  const repetition = diffClusters(baseline.patterns.repetitionClusters, revised.patterns.repetitionClusters);
  const pov = diffSignals(baseline.signals.povShifts, revised.signals.povShifts);
  const ten = diffSignals(baseline.signals.tenseShifts, revised.signals.tenseShifts);

  return {
    meta: { baselineLines: baseline.meta.lineCount, revisedLines: revised.meta.lineCount },
    curves: {
      emotional, imagery,
      summary: {
        emotionalMeanDelta: mean(emoD),
        emotionalAbsMeanDelta: absMean(emoD),
        imageryMeanDelta: mean(imgD),
        imageryAbsMeanDelta: absMean(imgD),
      }
    },
    repetition,
    signals: {
      povAdded: pov.added, povRemoved: pov.removed,
      tenseAdded: ten.added, tenseRemoved: ten.removed
    }
  };
}
