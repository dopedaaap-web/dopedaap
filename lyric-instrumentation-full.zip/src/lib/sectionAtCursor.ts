import type { SectionType } from "./sections";

function isHeading(line: string): boolean {
  const t = line.trim();
  if (!t) return false;
  if (/^[\[\(\{].+[\]\)\}]$/.test(t)) return true;
  return /^(intro|verse|pre[-\s]?chorus|chorus|bridge|outro|hook|interlude|instrumental|inst\.?|breakdown|break|drop|solo)\b[\s0-9a-z-]*[:\-–—]?\s*$/i.test(t);
}

function normalizeHeading(line: string): { type: SectionType; label: string } {
  let t = line.trim();
  if (/^[\[\(\{].+[\]\)\}]$/.test(t)) t = t.slice(1, -1).trim();
  t = t.replace(/[:\-–—]\s*$/g, "").trim();
  const s = t.toLowerCase();

  if (/(pre[\s-]?chorus|prechorus)/.test(s)) return { type: "prechorus", label: "Pre-Chorus" };
  if (/chorus|refrain/.test(s)) return { type: "chorus", label: "Chorus" };
  if (/verse/.test(s)) return { type: "verse", label: "Verse" };
  if (/bridge|middle\s*8/.test(s)) return { type: "bridge", label: "Bridge" };
  if (/intro/.test(s)) return { type: "intro", label: "Intro" };
  if (/outro|ending/.test(s)) return { type: "outro", label: "Outro" };
  if (/(instrumental|inst\.?|drop|solo|no\s*vocals)/.test(s)) return { type: "instrumental", label: "Instrumental" };
  if (/interlude|breakdown|break/.test(s)) return { type: "interlude", label: "Interlude" };
  if (/hook/.test(s)) return { type: "hook", label: "Hook" };

  return { type: "unknown", label: t || "Section" };
}

export function sectionAtCursor(text: string, cursor: number): { type: SectionType; label: string } {
  const before = text.slice(0, cursor);
  const lines = before.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    if (isHeading(lines[i])) return normalizeHeading(lines[i]);
  }
  return { type: "unknown", label: "Section" };
}
