import { NextResponse } from "next/server";

type Mode = "syn" | "related" | "rhyme" | "sound";

function buildDatamuseUrl(word: string, mode: Mode) {
  const base = "https://api.datamuse.com/words";
  const q = new URLSearchParams();
  q.set("max", "24");

  if (mode === "syn") q.set("rel_syn", word);
  if (mode === "related") q.set("ml", word);
  if (mode === "rhyme") q.set("rel_rhy", word);
  if (mode === "sound") q.set("sl", word);

  return `${base}?${q.toString()}`;
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const word = (searchParams.get("word") || "").trim().toLowerCase();
  const mode = (searchParams.get("mode") || "related") as Mode;

  if (!word) return NextResponse.json({ word, mode, results: [] });

  const url = buildDatamuseUrl(word, mode);

  const res = await fetch(url, { next: { revalidate: 60 } });
  if (!res.ok) return NextResponse.json({ word, mode, results: [] });

  const data = (await res.json()) as Array<{ word: string; score?: number; tags?: string[] }>;
  return NextResponse.json({
    word,
    mode,
    results: data.map((d) => ({ word: d.word, score: d.score ?? null, tags: d.tags ?? [] })),
  });
}
