"use client";

import React, { useMemo, useRef, useState } from "react";
import { Card } from "@/components/Card";
import { SuggestionDrawer } from "@/components/SuggestionDrawer";
import { buildLyricFingerprint, type LyricFingerprint } from "@/lib/lyricFingerprint";
import { buildDeltaReport, type DeltaReport } from "@/lib/delta";
import { sectionAtCursor } from "@/lib/sectionAtCursor";
import { buildHookContext, type HookContext } from "@/lib/hookContext";
import { findTriggerAtCursor, replaceRange } from "@/lib/insertAtCursor";

const BASELINE_DEMO = `[Intro – Instrumental]
(no vocals, slow swell)

[Verse 1]
I had to leave, I’m sorry there was no goodbye
The room was thin, the air would not comply
I held the line while every light went out
I kept my breath like it could save us now

[Pre-Chorus]
You won’t believe how quiet hope can get
I count the seconds like a loaded debt

[Chorus]
So close your eyes, feel my voice inside
I’m still with you, every day and night
So close your eyes, don’t let the dark decide
I’m still with you, every day and night

[Instrumental]
(drums drop, guitar shimmer, no vocals)

[Verse 2]
I watched the rain redraw the same old street
I saw your name in dust beneath my feet
They said “move on” like moving is a switch
But memory is muscle and it twitches

[Bridge]
If they paint me wrong, if they turn away
Play this song and you’ll hear me say

[Outro – Instrumental]
(no vocals, fade)`;

const REVISED_DEMO = `[Intro – Instrumental]
(no vocals, slow swell)

[Verse 1]
I had to leave, I’m sorry there was no goodbye
The room was wrong, the air would not align
I held the line while every light went out
I kept my breath like it could pull you back

[Pre-Chorus]
You won’t believe how heavy silence gets
I count the seconds like a loaded debt

[Chorus]
So close your eyes, I'm still in grief?
I’m still with you, every day and night
So close your eyes, don’t let the dark decide
I’m still with you, every day and night

[Instrumental]
(no vocals, tension rises)

[Verse 2]
I watched the rain erase the same old street
I felt your name in dust beneath my feet
They said “move on” like moving is a switch
But grief is honest—still, it twitches

[Bridge]
If they paint me wrong, if they turn away
Play this song and you’ll hear me say

[Outro – Instrumental]
(no vocals, fade)`;

function sparkline(values: number[], width = 320, height = 70): string {
  if (!values.length) return "";
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const step = width / Math.max(1, values.length - 1);
  const pts = values.map((v, i) => {
    const x = i * step;
    const y = height - ((v - min) / span) * height;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  return `M ${pts[0]} ` + pts.slice(1).map((p) => `L ${p}`).join(" ");
}

function cursorLineNumber(text: string, cursor: number): number {
  const before = text.slice(0, cursor);
  const lines = before.split(/\r?\n/);
  let n = 0;
  for (const l of lines) {
    const t = l.trim();
    if (!t) continue;
    const isHeading =
      /^[\[\(\{].+[\]\)\}]$/.test(t) ||
      /^(intro|verse|pre[-\s]?chorus|chorus|bridge|outro|hook|interlude|instrumental|inst\.?|breakdown|break|drop|solo)\b/i.test(t);
    if (isHeading) continue;
    n += 1;
  }
  return Math.max(1, n);
}

function sectionIndexForLine(fp: LyricFingerprint, lineNum: number): number | null {
  for (const s of fp.sections.metrics) {
    if (lineNum >= s.startLine && lineNum <= s.endLine) return s.index;
  }
  return null;
}

export default function Home() {
  const [baselineLyrics, setBaselineLyrics] = useState(BASELINE_DEMO);
  const [revisedLyrics, setRevisedLyrics] = useState(REVISED_DEMO);

  const [baselineFp, setBaselineFp] = useState<LyricFingerprint>(() => buildLyricFingerprint(BASELINE_DEMO));
  const [revisedFp, setRevisedFp] = useState<LyricFingerprint>(() => buildLyricFingerprint(REVISED_DEMO));
  const [delta, setDelta] = useState<DeltaReport>(() => buildDeltaReport(baselineFp, revisedFp));

  // suggestion drawer state (revised box)
  const revisedRef = useRef<HTMLTextAreaElement | null>(null);
  const [cursor, setCursor] = useState(0);
  const [sectionCtx, setSectionCtx] = useState<{ type: any; label: string } | null>(null);
  const [drawer, setDrawer] = useState<{ word: string; mode: "syn" | "rhyme" } | null>(null);
  const [activeTrigger, setActiveTrigger] = useState<{ start: number; end: number; word: string; mode: "syn" | "rhyme" } | null>(null);
  const [hookCtx, setHookCtx] = useState<HookContext | null>(null);

  const emoPathBaseline = useMemo(() => sparkline(baselineFp.curves.emotionalTrajectory), [baselineFp]);
  const emoPathRevised = useMemo(() => sparkline(revisedFp.curves.emotionalTrajectory), [revisedFp]);

  function runCompare() {
    const a = buildLyricFingerprint(baselineLyrics);
    const b = buildLyricFingerprint(revisedLyrics);
    setBaselineFp(a);
    setRevisedFp(b);
    setDelta(buildDeltaReport(a, b));
  }

  function onRevisedEdit(val: string, pos: number) {
    setRevisedLyrics(val);
    setCursor(pos);
    setSectionCtx(sectionAtCursor(val, pos));

    const trig = findTriggerAtCursor(val, pos);
    setActiveTrigger(trig);
    setDrawer(trig ? { word: trig.word, mode: trig.mode } : null);

    if (trig) {
      const lineNum = cursorLineNumber(val, pos);
      const tempFp = buildLyricFingerprint(val);
      const secIndex = sectionIndexForLine(tempFp, lineNum);
      setHookCtx(buildHookContext(tempFp, lineNum, secIndex));
    } else {
      setHookCtx(null);
    }
  }

  return (
    <main style={{ maxWidth: 1200, margin: "0 auto", padding: 24 }}>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>Lyric Instrumentation Demo</h1>
      <p style={{ marginTop: 0, opacity: 0.75 }}>
        Deterministic mirror + delta + section/prosody/rhyme + hook-aware word suggestions.
      </p>

      <section style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 16 }}>
        <Card title="Baseline Lyrics">
          <div style={{ fontSize: 12, opacity: 0.75, marginBottom: 6 }}>
            {baselineFp.meta.lineCount} lines · {baselineFp.meta.wordCount} words
          </div>
          <textarea
            value={baselineLyrics}
            onChange={(e) => setBaselineLyrics(e.target.value)}
            rows={16}
            style={{
              width: "100%",
              borderRadius: 10,
              border: "1px solid #ddd",
              padding: 12,
              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
              fontSize: 13
            }}
          />
        </Card>

        <Card title="Revised Lyrics (type word? / word~)">
          <div style={{ fontSize: 12, opacity: 0.75, marginBottom: 6 }}>
            {revisedFp.meta.lineCount} lines · {revisedFp.meta.wordCount} words
          </div>
          <textarea
            ref={revisedRef}
            value={revisedLyrics}
            onChange={(e) => {
              const val = e.target.value;
              const pos = e.target.selectionStart ?? val.length;
              onRevisedEdit(val, pos);
            }}
            onKeyUp={(e) => {
              const el = e.currentTarget;
              const pos = el.selectionStart ?? el.value.length;
              onRevisedEdit(el.value, pos);
            }}
            rows={16}
            style={{
              width: "100%",
              borderRadius: 10,
              border: "1px solid #ddd",
              padding: 12,
              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
              fontSize: 13
            }}
          />
          <div style={{ marginTop: 8, fontSize: 12, opacity: 0.65 }}>
            Cursor section: <strong>{sectionCtx?.label ?? "Section"}</strong>
          </div>
        </Card>
      </section>

      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <button
          onClick={runCompare}
          style={{
            borderRadius: 10,
            padding: "10px 14px",
            border: "1px solid #111",
            background: "#111",
            color: "#fff",
            cursor: "pointer"
          }}
        >
          Compare
        </button>
        <button
          onClick={() => {
            setBaselineLyrics(BASELINE_DEMO);
            setRevisedLyrics(REVISED_DEMO);
            const a = buildLyricFingerprint(BASELINE_DEMO);
            const b = buildLyricFingerprint(REVISED_DEMO);
            setBaselineFp(a);
            setRevisedFp(b);
            setDelta(buildDeltaReport(a, b));
          }}
          style={{
            borderRadius: 10,
            padding: "10px 14px",
            border: "1px solid #ddd",
            background: "#fff",
            cursor: "pointer"
          }}
        >
          Reset demo
        </button>
      </div>

      <section style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 12 }}>
        <Card title="Emotional Trajectory (Baseline vs Revised)">
          <svg width="100%" viewBox="0 0 320 70">
            <path d={emoPathBaseline} fill="none" stroke="currentColor" strokeWidth="2" opacity="0.35" />
            <path d={emoPathRevised} fill="none" stroke="currentColor" strokeWidth="2" />
          </svg>
          <div style={{ fontSize: 12, opacity: 0.75 }}>Overlay curves; same measurement, different draft.</div>
        </Card>

        <Card title="Delta Summary">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: 13 }}>
            <div>
              <div style={{ opacity: 0.7, fontSize: 12 }}>Emotional abs mean delta</div>
              <div>{delta.curves.summary.emotionalAbsMeanDelta.toFixed(3)}</div>
            </div>
            <div>
              <div style={{ opacity: 0.7, fontSize: 12 }}>Imagery abs mean delta</div>
              <div>{delta.curves.summary.imageryAbsMeanDelta.toFixed(3)}</div>
            </div>
          </div>
          <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>Abs mean = how much changed, not direction.</div>
        </Card>

        <Card title="Sections (Revised)">
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>
                  <th style={{ padding: "8px 6px" }}>#</th>
                  <th style={{ padding: "8px 6px" }}>Label</th>
                  <th style={{ padding: "8px 6px" }}>Lines</th>
                  <th style={{ padding: "8px 6px" }}>Avg Sent</th>
                  <th style={{ padding: "8px 6px" }}>Hook</th>
                </tr>
              </thead>
              <tbody>
                {revisedFp.sections.metrics.map((m) => (
                  <tr key={m.index} style={{ borderBottom: "1px solid #f0f0f0" }}>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{m.index}</td>
                    <td style={{ padding: "8px 6px" }}>
                      {m.label} <span style={{ opacity: 0.6, fontSize: 12 }}>({m.type})</span>
                    </td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>
                      {m.startLine}–{m.endLine} ({m.lineCount})
                    </td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{m.avgSentiment.toFixed(2)}</td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{m.hookZones.length ? m.hookZones.join(", ") : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card title="Instrumental Roles">
          {revisedFp.sections.instrumentalRoles.length ? (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #ddd", textAlign: "left" }}>
                    <th style={{ padding: "8px 6px" }}>Section</th>
                    <th style={{ padding: "8px 6px" }}>Role</th>
                    <th style={{ padding: "8px 6px" }}>Pos</th>
                    <th style={{ padding: "8px 6px" }}>Δ</th>
                    <th style={{ padding: "8px 6px" }}>Hook Dist</th>
                  </tr>
                </thead>
                <tbody>
                  {revisedFp.sections.instrumentalRoles.map((r, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid #f0f0f0" }}>
                      <td style={{ padding: "8px 6px", opacity: 0.75 }}>Instrumental #{r.sectionIndex}</td>
                      <td style={{ padding: "8px 6px" }}>{r.role}</td>
                      <td style={{ padding: "8px 6px", opacity: 0.75 }}>{r.positionPercent}%</td>
                      <td style={{ padding: "8px 6px", opacity: 0.75 }}>{r.deltaAcross !== null ? r.deltaAcross.toFixed(2) : "—"}</td>
                      <td style={{ padding: "8px 6px", opacity: 0.75 }}>{r.distanceToNearestHook ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div style={{ opacity: 0.75 }}>No instrumental sections detected.</div>
          )}
        </Card>

        <Card title="Prosody (Revised)">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, fontSize: 13 }}>
            <div>
              <div style={{ opacity: 0.7, fontSize: 12 }}>Avg syllables/line</div>
              <div>{revisedFp.prosody.summary.avgSyllables.toFixed(1)}</div>
            </div>
            <div>
              <div style={{ opacity: 0.7, fontSize: 12 }}>Syllable variance</div>
              <div>{revisedFp.prosody.summary.syllableStdDev.toFixed(1)}</div>
            </div>
            <div>
              <div style={{ opacity: 0.7, fontSize: 12 }}>Trip-risk avg</div>
              <div>{revisedFp.prosody.summary.tripRiskAvg.toFixed(2)}</div>
            </div>
          </div>
          <div style={{ marginTop: 10, overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #ddd", textAlign: "left" }}>
                  <th style={{ padding: "8px 6px" }}>Line</th>
                  <th style={{ padding: "8px 6px" }}>Syl</th>
                  <th style={{ padding: "8px 6px" }}>Risk</th>
                </tr>
              </thead>
              <tbody>
                {revisedFp.prosody.perLine.slice(0, 12).map((p) => (
                  <tr key={p.line} style={{ borderBottom: "1px solid #f0f0f0" }}>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{p.line}</td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{p.syllables}</td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{p.tripRisk.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card title="Rhyme Architecture (Revised)">
          <div style={{ fontSize: 13 }}>
            <div style={{ opacity: 0.7, fontSize: 12 }}>Adjacency stability</div>
            <div>{revisedFp.rhyme.stability.toFixed(2)}</div>
          </div>
          <div style={{ marginTop: 10, overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #ddd", textAlign: "left" }}>
                  <th style={{ padding: "8px 6px" }}>Line</th>
                  <th style={{ padding: "8px 6px" }}>End</th>
                  <th style={{ padding: "8px 6px" }}>Fam</th>
                </tr>
              </thead>
              <tbody>
                {revisedFp.rhyme.lines.slice(0, 14).map((r) => (
                  <tr key={r.line} style={{ borderBottom: "1px solid #f0f0f0" }}>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{r.line}</td>
                    <td style={{ padding: "8px 6px", opacity: 0.85 }}>{r.endWord ?? "—"}</td>
                    <td style={{ padding: "8px 6px", opacity: 0.75 }}>{r.family ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      <SuggestionDrawer
        trigger={drawer}
        section={sectionCtx as any}
        hookContext={hookCtx ? {
          anchorWords: hookCtx.anchorWords,
          rhymeKeys: hookCtx.rhymeKeys,
          alliterationStarts: hookCtx.alliterationStarts
        } : null}
        onClose={() => {
          setDrawer(null);
          setActiveTrigger(null);
        }}
        onSelect={(word) => {
          setRevisedLyrics((prev) => {
            if (!activeTrigger) return prev;
            return replaceRange(prev, activeTrigger.start, activeTrigger.end, `${word} `);
          });

          requestAnimationFrame(() => {
            const el = revisedRef.current;
            if (!el || !activeTrigger) return;
            const newPos = activeTrigger.start + word.length + 1;
            el.focus();
            el.setSelectionRange(newPos, newPos);
          });

          setDrawer(null);
          setActiveTrigger(null);
        }}
      />
    </main>
  );
}
