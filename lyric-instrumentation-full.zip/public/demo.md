[Verse]
I stayed up waiting for the call
The room was thin, the night too tall

[Chorus]
So close your eyes, I'm still in grief?

[Instrumental]
(no vocals)

[Verse]
Morning breaks but nothing moves
I walk the lines I never choose
