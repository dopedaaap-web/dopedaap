# Lyric Instrumentation Tool (Full Demo)

Deterministic lyric instrumentation tool: sections (incl. instrumental), prosody, rhyme mapping, repetition/hook zones,
delta comparison, plus section-aware & hook-aware word suggestions with cursor-accurate insertion.

## Run
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Triggers
- Type `word?` and keep cursor after `?` → synonyms/related drawer
- Type `word~` and keep cursor after `~` → rhymes/sounds-like drawer
- Use ↑/↓ + Enter, Esc to close

## Notes
- Word suggestions use Datamuse via `/api/words` proxy (no keys).
- All analysis is local/deterministic.
